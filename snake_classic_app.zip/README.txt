# Snake Classic — aplicativo web instalável

## Arquivos
- `index.html`: jogo completo
- `manifest.json`: configuração do app instalável
- `sw.js`: cache offline
- `icon-192.png` e `icon-512.png`: ícones do app

## Para instalar no iPhone
1. Publique estes arquivos em um serviço de hospedagem estática com HTTPS (por exemplo, GitHub Pages, Netlify ou Cloudflare Pages).
2. Abra o endereço publicado no Safari do iPhone.
3. Toque em **Compartilhar** → **Adicionar à Tela de Início** → **Adicionar**.

Depois, o ícone Snake abre o jogo em uma janela própria. O recorde fica salvo no dispositivo.

Observação: os arquivos estão prontos, mas ainda precisam ser hospedados num endereço HTTPS. Este pacote, sozinho, não publica o site nem instala o app automaticamente.
